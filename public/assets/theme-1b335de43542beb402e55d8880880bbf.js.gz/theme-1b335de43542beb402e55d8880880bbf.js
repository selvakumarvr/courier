
    // carousel demo

!function ($) {

    $('#myCarousel').carousel()
    
}(window.jQuery)

!function ($) {

    $('#myCarousel2').carousel()
    
}(window.jQuery)
;
